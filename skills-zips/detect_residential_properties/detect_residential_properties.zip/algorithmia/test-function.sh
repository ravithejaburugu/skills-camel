#!/usr/bin/env bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" 


cortex actions invoke cortex/detect_residential_properties_algorithmia --params-file "${SCRIPT_DIR}/test/test_req.json"
