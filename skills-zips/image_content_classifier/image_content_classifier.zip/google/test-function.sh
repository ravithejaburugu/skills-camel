#!/usr/bin/env bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" 


cortex actions invoke cortex/image_content_classifier_google --params-file "${SCRIPT_DIR}/test/test_req.json"
